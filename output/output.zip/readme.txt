Standard population: 450 visitors, 50 staff, 50% female, 85% staff in offices
Standard alertness: 3 threshold, 10 radious



final model V1 standard exit-spreadsheet 1:
- standard population
- standard alertness
- main entrance preferred
- Increase % of trained visitors from 0 to 100% every 10 runs (60 tot).

final model V1 standard exit alert threshold 10/20/30:
- same as above but alert threshold is 10/20/30



####### Question 2 ########################

final model V1 Different exits w workers:
- standard population
- alert threshold 10, 10 vision range
- prefered entrance varies (10 runs each)
- 0% trained visitors

final model V1 Different exits no workers -spreadsheet
- 500 visitors, no workers. 50% female
- alert threshold 10, 10 vision range
- prefered entrance varies (10 runs each)
- 0% trained visitors

final model V1 Different exits no workers 450 std alertness -spreadsheet
- 450 visitors, no workers. 50% female.
- standard alertness
- prefered entrance varies (10 runs each)
- 0% tarined visitors


####### Others ###########################

final model V1 (fe)males -spreadsheet:
- 100% male or female
- alert threshold 10, 10 vision range
- Main entrance
- 0% training

final model V1 Workers outside offices-spreadsheet:
- standard population
- alert threshold 10, 10 vision range
- main entrance
- 0% trained visitors
- workers inside offices vary from 0% to 100%, jumps of 25%
